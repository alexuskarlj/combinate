import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Model')

def lambda_handler(event, context):
    try:
        data = json.loads(event['body'])
        response = table.put_item(
            Item={
                'Id': data['Id'],
                'name': data['name'],
                'description': data['description'],
                'colour': data['colour'],
                'price_cents': data['price_cents']
            }
        )
        return {
            'statusCode': 200,
            'body': json.dumps('Product created successfully!')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps('Error: {}'.format(str(e)))
        }
