import json
import boto3
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Model')

def decimal_to_float(d):
    if isinstance(d, Decimal):
        return float(d)
    raise TypeError

def get_product_by_id(product_id):
    response = table.get_item(Key={'Id': product_id})
    if 'Item' in response:
        item = response['Item']
        item['price_cents'] = decimal_to_float(item['price_cents'])
        return item
    return None

def lambda_handler(event, context):
    try:
        product_id = event['pathParameters']['id']
        product = get_product_by_id(product_id)
        if product:
            response_body = json.dumps(product)
            return {
                'statusCode': 200,
                'body': response_body
            }
        else:
            return {
                'statusCode': 404,
                'body': json.dumps('Product not found')
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps('Error: {}'.format(str(e)))
        }
